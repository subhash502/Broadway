import { Component } from '@angular/core';
import { NavController, NavParams, AlertController } from 'ionic-angular';
import { AuthServiceProvider } from './../../providers/auth-service/auth-service';

@Component({
  selector: 'page-address',
  templateUrl: 'address.html',
})
export class AddressPage {
  public userDetails: any;
  public responseData: any;
  public dataset: any;
  userPostData = {"user_id":"", "token":"", "id":""};

  constructor(public navCtrl: NavController, public alert: AlertController, public navParams: NavParams, public authService: AuthServiceProvider) {
    const data = JSON.parse(localStorage.getItem('data'));
    this.userDetails = data.userData;
    this.userPostData.user_id = this.userDetails.user_id;
    this.userPostData.token = this.userDetails.token;
    this.getAddress();
  }

  getAddress(){
    this.authService.postData(this.userPostData,"getAddress").then((result) => {
      this.responseData = result;
      if(this.responseData.addressData){
        this.dataset = this.responseData.addressData;
      }else {
        console.log("No Access,,!");
      }
      
  },error => {
      let alert = this.alert.create({
          title: 'Warning',
          subTitle: 'There is an error! Please Try Again !',
          buttons: ['OK']
      });
      alert.present();
  });
  }

  addressDelete(id, msgIndex){
    if(id > 0)
    this.userPostData.id = id;
    console.log(this.userPostData);
    this.authService.postData(this.userPostData,"deleteAddress").then((result) => {
      this.responseData = result;
      console.log(this.responseData);
      if(this.responseData.success){
       this.dataset.splice(msgIndex, 1);
      }else {
        console.log("No Access,,!");
      }
      
  },error => {
      let alert = this.alert.create({
          title: 'Warning',
          subTitle: 'There is an error! Please Try Again !',
          buttons: ['OK']
      });
      alert.present();
  });
  }


}
