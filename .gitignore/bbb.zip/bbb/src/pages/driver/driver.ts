import { ShippingPage } from './../shipping/shipping';
import { NormalPage } from './../normal/normal';
import { ExpressPage } from './../express/express';
import { LoginPage } from './../login/login';
import { Component } from '@angular/core';
import { NavController, NavParams, App, AlertController } from 'ionic-angular';
import { NormalDPage } from './../normal-d/normal-d';
import { ExpressDPage } from './../express-d/express-d';
import { AuthServiceProvider } from './../../providers/auth-service/auth-service';
import { Http, Headers } from '@angular/http';

@Component({
  selector: 'page-driver',
  templateUrl: 'driver.html',
})
export class DriverPage {

  tab1Root = ExpressPage;
  tab2Root = NormalPage;
  tab3Root = ExpressDPage;
  tab4Root = NormalDPage;

  userDetails: any;
  public responseData: any;
  public eplength = 0;
  public nplength = 0;
  public edlength = 0;
  public ndlength = 0;
  userPostData = {"user_id":"", "token":""};


  constructor(public navCtrl: NavController, private http: Http, public navParams: NavParams, public app: App, public alert: AlertController, public authService: AuthServiceProvider) { 
    const data = JSON.parse(localStorage.getItem('data'));
    this.userDetails = data.userData;
    this.userPostData.user_id = this.userDetails.user_id;
    this.userPostData.token = this.userDetails.token;

    this.epickup();
    this.edelivery();
    this.npickup();
    this.ndelivery();
  }

  epickup(){
    let data=JSON.stringify(this.userPostData);
    this.http.post('http://www.broadway-bubbles.com/PHP-Slim/api/index.php/expressPickup', data).subscribe((res) => {
      const response = res.json()
      this.responseData = response;
      if(this.responseData.addressData.length != 0 && this.responseData.addressData.length != null){
        this.eplength = this.responseData.addressData.length;
      }else {
        this.eplength = 0;
      }
      
  },error => {
      let alert = this.alert.create({
          title: 'Warning',
          subTitle: 'There is an error! Please Try Again !',
          buttons: ['OK']
      });
      alert.present();
  });
  }

  npickup(){
    let data=JSON.stringify(this.userPostData);
    this.http.post('http://www.broadway-bubbles.com/PHP-Slim/api/index.php/normalPickup', data).subscribe((res) => {
      const response = res.json()
      this.responseData = response;
      if(this.responseData.addressData.length != 0 && this.responseData.addressData.length != null){
        this.nplength = this.responseData.addressData.length;
      }else {
        this.nplength = 0;
      }
      
  },error => {
      let alert = this.alert.create({
          title: 'Warning',
          subTitle: 'There is an error! Please Try Again !',
          buttons: ['OK']
      });
      alert.present();
  });
  }

  edelivery(){
    let data=JSON.stringify(this.userPostData);
    this.http.post('http://www.broadway-bubbles.com/PHP-Slim/api/index.php/expressDelivery', data).subscribe((res) => {
      const response = res.json()
      this.responseData = response;
      if(this.responseData.addressData.length != 0 && this.responseData.addressData.length != null){
        this.edlength = this.responseData.addressData.length;
      }else {
        this.edlength = 0;
      }
      
  },error => {
      let alert = this.alert.create({
          title: 'Warning',
          subTitle: 'There is an error! Please Try Again !',
          buttons: ['OK']
      });
      alert.present();
  });
  }

  ndelivery(){
    let data=JSON.stringify(this.userPostData);
    this.http.post('http://www.broadway-bubbles.com/PHP-Slim/api/index.php/normalDelivery', data).subscribe((res) => {
      const response = res.json()
      this.responseData = response;
      if(this.responseData.addressData.length != 0 && this.responseData.addressData.length != null){
        this.ndlength = this.responseData.addressData.length;
      }else {
        this.ndlength = 0;
      }
      
  },error => {
      let alert = this.alert.create({
          title: 'Warning',
          subTitle: 'There is an error! Please Try Again !',
          buttons: ['OK']
      });
      alert.present();
  });
  }

}
