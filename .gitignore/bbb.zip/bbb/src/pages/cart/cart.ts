import { PaymentPage } from './../payment/payment';
import { Storage } from '@ionic/storage';
import { Component } from '@angular/core';
import { NavController, NavParams, AlertController } from 'ionic-angular';
import { AuthServiceProvider } from './../../providers/auth-service/auth-service';
import { OrdersDetailPage } from '../orders-detail/orders-detail';

@Component({
  selector: 'page-cart',
  templateUrl: 'cart.html',
})
export class CartPage {

  cartItems: any[] = [];
  total: any;
  time: any;
  showEmptyCartMessage: boolean = false;
  default: any;
  order: any;
  userLoginData: any;
  address: any;
  apt: any;

  constructor(private alert :AlertController, public navCtrl: NavController, public authService : AuthServiceProvider, public navParams: NavParams, public storage: Storage) {

    this.order = {"user_id":"","express_delivery": "","payment_method":"","items":[],"token":"","total":"","apt":"","address":"","lat":"","lng":"","customer_id":"","pickup_time":"","email":""};

    this.total = 0.0;

    this.storage.ready().then(()=>{
      
            this.storage.get("time").then((data)=>{
              this.time = data.slice(11,16);
          });
      
          //Express Delivery
          this.storage.get("updateItem").then((data) => {
            if(data != null && data.length != 0){
              if(data[0].option === "yes"){
                this.order.express_delivery = "yes";
              }else{
                this.order.express_delivery = "no";
              }
            }
          })

          this.storage.get("payment_method").then((data) => {
            if(data != null && data.length != 0){
              this.order.payment_method = data[0].name;
            }else {
              this.order.payment_method = "Stripe"
            }
            console.log(data);
          })
      
          this.storage.get("addr").then((data)=>{
            if(data != null && data != 0){
               this.apt = data[0].apt;
               this.address = data[0].full_address
               this.order.address = data[0].full_address;
               this.order.apt = data[0].apt;
               this.order.lat = data[0].lat;
               this.order.lng = data[0].lng;
              }
          })
          this.storage.get("pay").then((data)=>{
            if(data != null && data != 0){
               this.order.customer_id = data[0].customer_id;
              }
          })
          this.storage.get("time").then((data)=>{
            console.log(data);
            if(data){
              let time = data;
               this.order.pickup_time = time.slice(11,16);
              }
          })
      
            this.storage.get("cart").then((data)=>{
              this.cartItems = data;
      
              if(this.cartItems != null){
                this.cartItems.forEach((item, index) =>{
                  this.total = this.total + item.price
                })
              } else {
                this.showEmptyCartMessage = true;
              }
            })
      
          })
}

removeFromCart(item, i){
  let price = item.price;
  let qty = item.qty;

      this.storage.get("washingData").then((data) => {
        for(let j = 0; j < data.length; j++) {
            if(item.name == data[j].name) {
            data[j].qty = false;
          }
          this.storage.set("washingData",data)
        }
      })

    this.storage.get("dryCleaningData").then((data)=>{
      for(let i = 0; i < data.length; i++) {
        if(item.name == data[i].name) {
          data[i].qty = 0;
        }
      }
      this.storage.set("dryCleaningData", data);
    })

    this.storage.get("beddingData").then((data)=>{
      for(let i = 0; i < data.length; i++) {
        if(item.name == data[i].name) {
          data[i].qty = 0;
        }
      }
      this.storage.set("beddingData", data);
    })

    this.storage.get("washPressData").then((data)=>{
      for(let i = 0; i < data.length; i++) {
        if(item.name == data[i].name) {
          data[i].qty = 0;
        }
      }
      this.storage.set("washPressData", data);
    })

  this.cartItems.splice(i, 1);

  this.storage.set("cart", this.cartItems).then(()=>{
    this.total = this.total - price; 
  });
  if(this.cartItems.length == 0) {
    this.showEmptyCartMessage = true;
  }
}

onPayment() {
  this.navCtrl.push(PaymentPage);
}

changeTime(data){
  let h;
  let m;
  if(data != null){
     h = data.slice(0,2);
     m = data.slice(2,5);
  }
    let s = ""
    if(h < 12){
      s = " AM";
    }else {
      h = h-12;
      s = " PM"
    }
    return h+m+s;
  }

  changeAddress(addr){
    let s;
    if(addr != null){
    s = addr.replace(' New York, NY', '');
    s = s.replace(', USA','');
    }
    return s;
  }

placeOrder(){
  this.order.items = this.cartItems;
  this.order.total = this.total.toString();
  if(localStorage.getItem('data')){
    this.userLoginData = JSON.parse(localStorage.getItem('data'));
    this.order.user_id = this.userLoginData.userData.user_id;
    this.order.token = this.userLoginData.userData.token;
    this.order.email = this.userLoginData.userData.email;
  }
  
  console.log(this.order);
  this.authService.postData(this.order,"placeOrder").then((result) => {
    if(result) {
      console.log(result);
      let alert = this.alert.create({
        title: 'Order Placed',
        subTitle: 'Driver will be there promptly',
        buttons: ['OK']
    });
    alert.present();
    // localStorage.removeItem('cart');
    // localStorage.removeItem('time');
    // localStorage.removeItem('addr');
    // localStorage.removeItem('pay');
    this.storage.get("cart").then((data) => {
      
          data = [];
          
      this.storage.set("cart",data);
    });
    this.storage.get("dryCleaningData").then((data) => {
      for(let j = 0; j < data.length; j++) {
        data[j].qty = 0;
    }  
    this.storage.set("dryCleaningData",data)
    })
    this.storage.get("washingData").then((data) => {
      for(let j = 0; j < data.length; j++) {
        data[j].qty = false;
    }  
    this.storage.set("washingData",data)
    })
    this.storage.get("beddingData").then((data) => {
      for(let j = 0; j < data.length; j++) {
        data[j].qty = 0;
    }  
    this.storage.set("beddingData",data)
    })
    this.storage.get("washPressData").then((data) => {
      for(let j = 0; j < data.length; j++) {
        data[j].qty = 0;
    }  
    this.storage.set("washPressData",data)
    })
    this.navCtrl.popTo(OrdersDetailPage);
    } 
  })
}

removeItemFromCart(item, i){
  this.storage.ready().then(()=>{
    let price;
    
        this.storage.get("cart").then((data) => {
          for(let j = 0; j < data.length; j++) {
              if(item.name == data[j].name) {
              let qty = data[j].qty;
              data[j].qty = qty-1;
              data[j].price = parseFloat(data[j].price) - parseFloat(item.price);
            }
          }     
          this.storage.set("cart",data).then(()=>{
            this.cartItems = data;
            this.total = this.total - item.price;
          })
        });
       
})
  

  //   this.storage.get("dryCleaningData").then((data)=>{
  //     for(let i = 0; i < data.length; i++) {
  //       if(item.name == data[i].name) {
  //         if(data[i].qty>0){
  //           let qty = data[i].qty;
  //           data[i].qty = qty-1;
  //           data[i].price = parseFloat(data[i].price) - parseFloat(item.amount);
  //           }
  //       }
  //     }
  //     this.storage.set("dryCleaningData", data);
  //   })

  //   this.storage.get("beddingData").then((data)=>{
  //     for(let i = 0; i < data.length; i++) {
  //       if(item.name == data[i].name) {
  //         if(data[i].qty>0){
  //           let qty = data[i].qty;
  //           data[i].qty = qty-1;
  //           data[i].price = parseFloat(data[i].price) - parseFloat(item.amount);
  //           }
            
  //       }
  //     }
  //     this.storage.set("beddingData", data);
  //   })

  //   this.storage.get("washPressData").then((data)=>{
  //     for(let i = 0; i < data.length; i++) {
  //       if(item.name == data[i].name) {
  //         if(data[i].qty>0){
  //           let qty = data[i].qty;
  //           data[i].qty = qty-1;
  //           data[i].price = parseFloat(data[i].price) - parseFloat(item.amount);
  //           }
            
  //       }
  //     }
  //     this.storage.set("washPressData", data);
  //   })
  
  // if(this.cartItems.length == 0) {
  //   this.showEmptyCartMessage = true;
  // }
}

}
