import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { CartItemPage } from './cart-item';

@NgModule({
  declarations: [
    CartItemPage,
  ],
  imports: [
    IonicPageModule.forChild(CartItemPage),
  ],
})
export class CartItemPageModule {}
