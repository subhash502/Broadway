import { Storage } from '@ionic/storage';
import { Component } from '@angular/core';
import { NavController, NavParams, ToastController, AlertController, ModalController } from 'ionic-angular';
import { AuthServiceProvider } from './../../providers/auth-service/auth-service';

@Component({
  selector: 'page-dry-cleaning',
  templateUrl: 'dry-cleaning.html'
})
export class DryCleaningPage {

  public dryCleaning: any;
  public cartItems: any;
  public dData: any;
  public qtydata: number;
  item: string;

  constructor(public navCtrl: NavController, public alert: AlertController, public authService: AuthServiceProvider, public toastCtrl: ToastController, public navParams: NavParams, public storage: Storage, public modalCtrl: ModalController) {
  
    this.getStorage();
   }

  getStorage(){
    this.storage.ready().then(()=>{
      this.storage.get("dryCleaningData").then((data) => {
        this.dryCleaning = data;
        console.log(this.dryCleaning);
      })
    });
  }

  addItem(id) {
    this.storage.ready().then(()=>{
          for(let i = 0; i < this.dryCleaning.length; i++) {
            if(id == this.dryCleaning[i].id) {
              this.storage.get("dryCleaningData").then((data) => {
                for(let j = 0; j < data.length; j++) {
                    if(id == data[j].id) {
                    let qty = data[j].qty;
                    data[j].qty = qty+1;
                  }
                  this.storage.set("dryCleaningData",data).then(()=>{
                    this.dryCleaning = data;
                  })
                }
                console.log(data);
            //let qty = parseInt(data[i].qty)+1;
            //data[i].qty = qty.toString();
            
            this.cart(data[i]);
            // this.storage.set("cleaningData",data).then(()=>{
            //   console.log(data);
            //   })
              });
        }
        }       
      })
      this.getStorage();
      //this.openModal();
 //window.location.reload();
  }

  deleteItem(id){
    
    this.storage.ready().then(()=>{
      for(let i = 0; i < this.dryCleaning.length; i++) {
        if(id == this.dryCleaning[i].id) {
          this.storage.get("dryCleaningData").then((data) => {
            for(let j = 0; j < data.length; j++) {
                if(id == data[j].id) {
                let qty = data[j].qty;
                data[j].qty = qty-1;
              }
              this.storage.set("dryCleaningData",data).then(()=>{
                this.dryCleaning = data;
              })
            }     
        this.removeFromCart(data[i]);
          });
    }
    }       
  })
  this.getStorage();
   
    }

  public cart(item){
    this.storage.get("cart").then((data) => {
      if(data == null || data.length ==0){
        data = [];
        data.push({
        "name": item.name,
        "qty": 1,
        "price": parseFloat(item.amount)
        });
        } else {
        let added = 0;
        for(let i = 0; i < data.length; i++) {
          if(item.name == data[i].name) {
          console.log("product added to cart");
          let qty = data[i].qty;
          data[i].qty = qty+1;
          data[i].price = parseFloat(data[i].price) + parseFloat(item.amount);
          added = 1;
          }	
        }
        if(added == 0) {
        data.push({
         "name": item.name,
         "qty": 1,
         "price": parseFloat(item.amount)
        });
        }
        }
        this.storage.set("cart",data).then(()=>{
        console.log(data);
        
        this.toastCtrl.create({
        message: "Cart Updated",
        duration: 3000
        }).present();	
        })
      });
      
      }

  removeFromCart(item){
    this.storage.get("cart").then((data) => {
      if(data !== null || data.length !== 0){
        for(let i = 0; i < data.length; i++) {
          if(item.name == data[i].name) {
          
          if(data[i].qty>0){
          let qty = data[i].qty;
          data[i].qty = qty-1;
          data[i].price = parseFloat(data[i].price) - parseFloat(item.amount);
          }
          if(data[i].qty == 0){
            data.splice(i,1);
          }
          }	
        }
        }
        this.storage.set("cart",data).then(()=>{
        
        this.toastCtrl.create({
        message: "Cart Updated",
        duration: 3000
        }).present();	
        })
      });
  }

  isValid(qty) {
    if(qty>0){
      return true;
    }else {
      return false;
    }
}

}
