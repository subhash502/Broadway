import { PaymentPage } from './../payment/payment';
import { Component } from '@angular/core';
import { NavController, NavParams, ViewController, AlertController } from 'ionic-angular';
import { AuthServiceProvider } from './../../providers/auth-service/auth-service';
import {Http, Headers} from '@angular/http';

@Component({
  selector: 'page-get-payment',
  templateUrl: 'get-payment.html',
})
export class GetPaymentPage {
  userLoginData: any;
  cardInfo: any;
  cardData: any;
  displayCard = {"token":""};
  public userPostData = {"user_id":"", "token":""};
  cardsList: Array<String> = [];

  constructor(private http: Http, public navCtrl: NavController, public alert: AlertController, public viewCtrl: ViewController, public navParams: NavParams, public authService: AuthServiceProvider) {
    if(localStorage.getItem('data')){
      this.userLoginData = JSON.parse(localStorage.getItem('data'));
      console.log(this.userLoginData);
      this.userPostData.user_id = this.userLoginData.userData.user_id;
      this.userPostData.token = this.userLoginData.userData.token;
    }
    this.authService.postData(this.userPostData,"getPayment").then((result) => {
      if(result){
      this.cardInfo = result;
      console.log(this.cardInfo.paymentData[0].customer_id);
      for(let i=0; i<this.cardInfo.paymentData.length; i++){
      this.displayCards(this.cardInfo.paymentData[i].customer_id);
      }
    }else {
      let alert = this.alert.create({
        title: 'Payment Method',
        subTitle: 'Please add Credit Card',
        buttons: ['OK',
        {
          text: 'Add Credit Card',
          handler: () => {
            this.navCtrl.push(PaymentPage)
          }
        }
      ]
    });
    alert.present();
    }
    });
  }
  
  close(){
    this.navCtrl.pop();
  }

  displayCards(customerId){
    this.http.get('http://localhost/stripe/getCardDetails.php?customer_id='+customerId).subscribe((res) => {
        this.cardData = res.json();
        console.log(this.cardData);
        this.cardsList.push(this.cardData);
        console.log(this.cardsList);
    })
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad GetPaymentPage');
  }

  closeModal(data) {
    this.viewCtrl.dismiss(data);
  }

}
