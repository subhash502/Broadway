import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { GetPaymentPage } from './get-payment';

@NgModule({
  declarations: [
    GetPaymentPage,
  ],
  imports: [
    IonicPageModule.forChild(GetPaymentPage),
  ],
})
export class GetPaymentPageModule {}
