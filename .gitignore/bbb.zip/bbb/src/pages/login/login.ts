import { Storage } from '@ionic/storage';
import { EmployeePage } from './../employee/employee';
import { DriverPage } from './../driver/driver';
import { AuthServiceProvider } from './../../providers/auth-service/auth-service';
import { Component } from '@angular/core';
import { NavController, AlertController, ToastController } from 'ionic-angular';
import { Validators, FormBuilder } from '@angular/forms';
import { SignupPage } from '../signup/signup';
import { MenuPage } from './../menu/menu';

@Component({
  selector: 'page-login',
  templateUrl: 'login.html',
})
export class LoginPage {
  resonseData : any;
  washingData: any;
  beddingData: any;
  washPressData: any;
    data : any;
    login_form : any;
    public responseData: any;
    dData: any;
  
    userLoginData: any;
    public userPostData = {"user_id":"", "token":""};
    constructor(public storage: Storage, public toastCtrl: ToastController, private navCtrl: NavController, public authService : AuthServiceProvider, public formbuilder :FormBuilder, private alert :AlertController) {
     
      if(localStorage.getItem('data')){
        this.userLoginData = JSON.parse(localStorage.getItem('data'));
        
        if(this.userLoginData.userData.status === "user")
        {
          this.navCtrl.push(MenuPage);
        } else if(this.userLoginData.userData.status === "driver") {
          this.navCtrl.push(DriverPage);
        } else if(this.userLoginData.userData.status === "employee") {
          this.navCtrl.push(EmployeePage);
        }        
  
      }
      this.login_form = this.formbuilder.group({
        "username": ["", Validators.required],
        "password": ["", Validators.required]
      })
  
      this.data = {};
      this.data.username = "";
      this.data.password = "";
    }
  
     login(){
      // let data = {"username":"", "password":""};
      console.log(this.data);
      this.authService.postData(this.data,"login").then((result) => {
        this.resonseData = result;
        console.log(this.resonseData);
        if(this.resonseData.userData){
          this.data.email = this.resonseData.email;
          localStorage.setItem('data',JSON.stringify(this.resonseData));
          
          if(this.resonseData.userData.status === "user")
          {
            this.userPostData.user_id = this.resonseData.userData.user_id;
            this.userPostData.token = this.resonseData.userData.token;
            this.getDryCleaningData();
            this.getWashingData();
            this.getBeddingData();
            this.getWashPressData();
            this.navCtrl.setRoot(MenuPage);
          } else if(this.resonseData.userData.status === "driver") {
            this.navCtrl.setRoot(DriverPage);
          } else if(this.resonseData.userData.status === "employee") {
            this.navCtrl.setRoot(EmployeePage);
          } 
        }else {
          this.presentToast("Invalid Username and/or Password");
        }
        

    },error => {
        let alert = this.alert.create({
            title: 'Warning',
            subTitle: 'There is an error! Please Try Again !',
            buttons: ['OK']
        });
        alert.present();
    });

    }

    getDryCleaningData(){
      console.log(this.userPostData);
      this.authService.postData(this.userPostData,"getDryCleaningData").then((result) => {
        this.responseData = result;
        console.log(this.responseData);
        if(this.responseData.dryCleaningData){
          
          this.storage.get("dryCleaningData").then((data) => {
            data = [];
            for(let i=0;i<this.responseData.dryCleaningData.length;i++){
          data.push({
            "id" : this.responseData.dryCleaningData[i].id,
            "name" : this.responseData.dryCleaningData[i].name,
            "price" : this.responseData.dryCleaningData[i].price_text,
            "amount" : this.responseData.dryCleaningData[i].amount,
            "qty" : 0
            });
            this.storage.set("dryCleaningData",data);
        }
        console.log(data);
        })
        }else {
          console.log("No Access,,!");
        }
        
    },error => {
        let alert = this.alert.create({
            title: 'Warning',
            subTitle: 'There is an error! Please Try Again !',
            buttons: ['OK']
        });
        alert.present();
    });
    }

    getWashingData(){
      console.log(this.userPostData);
      this.authService.postData(this.userPostData,"getWashingData").then((result) => {
        this.washingData = result;
        console.log(this.washingData);
        if(this.washingData.washingData){
          
          this.storage.get("washingData").then((data) => {
            data = [];
            for(let i=0;i<this.washingData.washingData.length;i++){
          data.push({
            "id" : this.washingData.washingData[i].id,
            "name" : this.washingData.washingData[i].name,
            "price" : this.washingData.washingData[i].price_text,
            "amount" : this.washingData.washingData[i].amount,
            "qty" : false
            });
            this.storage.set("washingData",data);
        }
        })
        }else {
          console.log("No Access,,!");
        }
        
    },error => {
        let alert = this.alert.create({
            title: 'Warning',
            subTitle: 'There is an error! Please Try Again !',
            buttons: ['OK']
        });
        alert.present();
    });
    }

    getBeddingData(){
      this.authService.postData(this.userPostData,"getBeddingData").then((result) => {
        this.beddingData = result;
        console.log(this.beddingData);
        if(this.beddingData.beddingData){
          
          this.storage.get("beddingData").then((data) => {
            data = [];
            for(let i=0;i<this.beddingData.beddingData.length;i++){
          data.push({
            "id" : this.beddingData.beddingData[i].id,
            "name" : this.beddingData.beddingData[i].name,
            "price" : this.beddingData.beddingData[i].price_text,
            "amount" : this.beddingData.beddingData[i].amount,
            "qty" : 0
            });
            this.storage.set("beddingData",data);
        }
        })
        }else {
          console.log("No Access,,!");
        }
        
    },error => {
        let alert = this.alert.create({
            title: 'Warning',
            subTitle: 'There is an error! Please Try Again !',
            buttons: ['OK']
        });
        alert.present();
    });
    }

    getWashPressData(){
      this.authService.postData(this.userPostData,"getWashPressData").then((result) => {
        this.washPressData = result;
        console.log(this.washPressData);
        if(this.washPressData.washPressData){
          
          this.storage.get("washPressData").then((data) => {
            data = [];
            for(let i=0;i<this.washPressData.washPressData.length;i++){
          data.push({
            "id" : this.washPressData.washPressData[i].id,
            "name" : this.washPressData.washPressData[i].name,
            "price" : this.washPressData.washPressData[i].price_text,
            "amount" : this.washPressData.washPressData[i].amount,
            "qty" : 0
            });
            this.storage.set("washPressData",data);
        }
        })
        }else {
          console.log("No Access,,!");
        }
        
    },error => {
        let alert = this.alert.create({
            title: 'Warning',
            subTitle: 'There is an error! Please Try Again !',
            buttons: ['OK']
        });
        alert.present();
    });
    }
      
    onGoToSignup() {
      this.navCtrl.push(SignupPage);
    }

    presentToast(msg){
      let toast = this.toastCtrl.create({
        message: msg,
        duration: 2000
      });
      toast.present();
    }

}
