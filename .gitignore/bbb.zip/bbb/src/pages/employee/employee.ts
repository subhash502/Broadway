import { LoginPage } from './../login/login';
import { EmpOrderDetailsPage } from './../emp-order-details/emp-order-details';
import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, AlertController } from 'ionic-angular';
import { AuthServiceProvider } from './../../providers/auth-service/auth-service';
import { Storage } from '@ionic/storage';

@IonicPage()
@Component({
  selector: 'page-employee',
  templateUrl: 'employee.html',
})
export class EmployeePage {

  public userDetails: any;
  public responseData: any;
  public orderDetails: any;
  public dataset: any;
  userPostData = {"user_id":"", "token":"", "order_token":""};

  length = 0;

  empOrdersList: Array<String> = [];

  constructor(public storage: Storage ,public navCtrl: NavController, public authService: AuthServiceProvider, public navParams: NavParams, public alert: AlertController) {
    const data = JSON.parse(localStorage.getItem('data'));
    this.userDetails = data.userData;
    this.userPostData.user_id = this.userDetails.user_id;
    this.userPostData.token = this.userDetails.token;

    this.getAddress();
  }

  getAddress(){
    this.authService.postData(this.userPostData,"empOrderList").then((result) => {
      this.responseData = result;
      if(this.responseData.empOrderData == null || this.responseData.empOrderData.length == 0){
        let alert = this.alert.create({
          title: 'Orders',
          subTitle: 'There are no new orders',
          buttons: ['OK']
      });
      alert.present();
      }else {
        this.length = this.responseData.empOrderData.length;
        for(let i=0; i<this.responseData.empOrderData.length;i++){
          this.empOrdersList.push(this.responseData.empOrderData[i]);
        }
        //console.log(this.empOrdersList);
        // this.dataset = this.responseData.addressData;
        // console.log(this.dataset);
      }
      
  },error => {
      let alert = this.alert.create({
          title: 'Warning',
          subTitle: 'There is an error! Please Try Again !',
          buttons: ['OK']
      });
      alert.present();
  });
  }

  openOrder(data){ 
    //console.log(data.order_token)
    this.storage.get("empOrderDetails").then((result) => {
      this.userPostData.order_token = data.order_token;
      this.authService.postData(this.userPostData,"orderItemList").then((something) => {
        //console.log(something)
        this.orderDetails = something
        
          this.storage.get("orderItemDetails").then((ItemList) => {
            ItemList = [];
            for(let i=0;i<this.orderDetails.orderItemData.length;i++){
            ItemList.push({
              "created_at" : this.orderDetails.orderItemData[i].created_at,
              "id" : this.orderDetails.orderItemData[i].id,
              "item_name" : this.orderDetails.orderItemData[i].item_name,
              "item_price" : parseFloat(this.orderDetails.orderItemData[i].item_price),
              "item_qty" : parseInt(this.orderDetails.orderItemData[i].item_qty),
              "order_token" : this.orderDetails.orderItemData[i].order_token,
              "user_id" : parseInt(this.orderDetails.orderItemData[i].user_id)
              });
            }
              this.storage.set("orderItemDetails",ItemList).then(()=>{
                this.orderDetails = ItemList;
                //console.log(ItemList)
              });
          })
        //console.log(this.orderDetails.orderItemData.length)
      })
      
      result = [];
      result.push({
        "amount" : parseFloat(data.amount),
        "created_at" : data.created_at,
        "customer_id" : data.customer_id,
        "express_delivery" : data.express_delivery,
        "order_id" : parseInt(data.order_id),
        "order_status" : data.order_status,
        "order_token" : data.order_token,
        "payment_method" : data.payment_method,
        "pickup_time" : data.pickup_time,
        "user_id": parseInt(data.user_id),
        "weight" : data.weight,
        });
        this.storage.set("empOrderDetails",result);

      this.jump();
    })
  }

  jump(){
    this.navCtrl.push(EmpOrderDetailsPage)
  }

  logout(){
    this.navCtrl.setRoot(LoginPage);
    this.navCtrl.popTo(LoginPage)
  }
}
