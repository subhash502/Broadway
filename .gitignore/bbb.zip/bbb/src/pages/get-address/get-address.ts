import { PageGmapAutocompletePage } from './../page-gmap-autocomplete/page-gmap-autocomplete';
import { Component } from '@angular/core';
import { NavController, NavParams, ViewController, AlertController, ToastController } from 'ionic-angular';
import { AuthServiceProvider } from './../../providers/auth-service/auth-service';
import { Storage } from '@ionic/storage';

@Component({
  selector: 'page-get-address',
  templateUrl: 'get-address.html',
})
export class GetAddressPage {

  public userDetails: any;
  public responseData: any;
  public dataset: any;
  userPostData = {"user_id":"", "token":""};

  addrsList: Array<String> = [];

  constructor(public navCtrl: NavController, public toastCtrl: ToastController, public storage: Storage, public navParams: NavParams, public viewCtrl: ViewController, public authService: AuthServiceProvider, public alert: AlertController) {
    const data = JSON.parse(localStorage.getItem('data'));
    this.userDetails = data.userData;
    this.userPostData.user_id = this.userDetails.user_id;
    this.userPostData.token = this.userDetails.token;

    this.getAddress();
  }

  close(){
    this.navCtrl.pop();
  }

  addAddress(){
    this.navCtrl.push(PageGmapAutocompletePage);
  }

  getAddress(){
    this.authService.postData(this.userPostData,"getAddress").then((result) => {
      this.responseData = result;
      if(this.responseData.addressData == null || this.responseData.addressData.length == 0){
        let alert = this.alert.create({
          title: 'Address',
          subTitle: 'Please add new address',
          buttons: ['OK',
          {
            text: 'Create New address',
            handler: () => {
              this.navCtrl.push(PageGmapAutocompletePage)
            }
          }
        ]
      });
      alert.present();
      }else {
        for(let i=0; i<this.responseData.addressData.length;i++){
          this.addrsList.push(this.responseData.addressData[i]);
        }
        console.log(this.addrsList);
        // this.dataset = this.responseData.addressData;
        // console.log(this.dataset);
      }
      
  },error => {
      let alert = this.alert.create({
          title: 'Warning',
          subTitle: 'There is an error! Please Try Again !',
          buttons: ['OK']
      });
      alert.present();
  });
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad GetAddressPage');
  }

  closeModal(data) {
    this.toastCtrl.create({
      message: "Address Added",
      duration: 3000
      }).present();
    this.viewCtrl.dismiss(data);
  }

}
