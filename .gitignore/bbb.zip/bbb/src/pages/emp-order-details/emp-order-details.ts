import { EmployeePage } from './../employee/employee';
import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, AlertController, LoadingController } from 'ionic-angular';
import { Storage } from '@ionic/storage';
import { Http, Headers } from '@angular/http';
import { AuthServiceProvider } from './../../providers/auth-service/auth-service';

@IonicPage()
@Component({
  selector: 'page-emp-order-details',
  templateUrl: 'emp-order-details.html',
})
export class EmpOrderDetailsPage { 

  public empOrderData: any
  public data: any;
  public order: any;
  public orderItemDetails: any;
  public ItemDetails: any;
  public variableItemsData: any;
  public variableItemsPriceData: any;

  public userDetails: any;
  public responseData: any;
  public bedding_price: any;
  public drycleaning_price: any;

  formData : any;
  amount: any;
  price = '0';
  userPostData = {"user_id":"", "token":""};
  //amount : any;
  loader: any;
  public bedding: Array<String> = [];
  public drycleaning: Array<String> = [];

  public bed_items: Array<String> = [];
  public dry_items: Array<String> = [];

  constructor(public authService : AuthServiceProvider, public loadingCtrl: LoadingController, private http: Http, public alert: AlertController, public storage: Storage, public navCtrl: NavController, public navParams: NavParams) {
    this.empOrderData = {}
    this.storage.get("empOrderDetails").then((result) => {
      this.empOrderData = result[0]
      console.log(this.empOrderData)
      // this.amount = parseFloat(this.empOrderData.amount);
    })

    this.bedding_price = 0.0;
    this.drycleaning_price = 0.0;
    
    this.data = {}
    this.data.customer_id = "";
    this.data.amount = 0.0;    

    this.order = {}

    const userData = JSON.parse(localStorage.getItem('data'));
    this.userDetails = userData.userData;
    this.userPostData.user_id = this.userDetails.user_id;
    this.userPostData.token = this.userDetails.token;

    this.authService.postData(this.userPostData,"variableItemsPrice").then((result) => {
      this.variableItemsPriceData = result;
      },error => {
          let alert = this.alert.create({
              title: 'Warning',
              subTitle: 'There is an error! Please Try Again !',
              buttons: ['OK']
          });
          alert.present();
      });
    
    this.getPrice();
    this.getVariableItems();

  }

  getTotal(){
    let total = parseFloat(this.data.weight)*parseFloat(this.price);
    
        this.amount = this.amount + total;
  }


  getPrice(){
    this.authService.postData(this.userPostData,"washPrice").then((result) => {
      this.responseData = result;
      if(this.responseData.washPriceData == null || this.responseData.washPriceData.length == 0){
        let alert = this.alert.create({
          title: 'Warning',
          subTitle: 'There is no price per pound',
          buttons: ['OK']
      });
      alert.present();
      }else {
        this.price = this.responseData.washPriceData[0].price;
      }
      
  },error => {
      let alert = this.alert.create({
          title: 'Warning',
          subTitle: 'There is an error! Please Try Again !',
          buttons: ['OK']
      });
      alert.present();
  });
  }


  getVariableItems(){
    this.authService.postData(this.userPostData,"variableItems").then((result) => {
      this.variableItemsData = result;
      this.storage.get("orderItemDetails").then((data) => {
        this.ItemDetails = data;
        if(this.ItemDetails.length != 0){
          this.amount = 0.0;
        for(let i = 0; i < this.ItemDetails.length; i++){
          this.amount += this.ItemDetails[i].item_price;
          for(let j = 0; j < this.variableItemsData.variableItemsData.length; j++ ){
            if(this.ItemDetails[i].item_name === this.variableItemsData.variableItemsData[j].name){
              if(this.ItemDetails[i].item_name === "Blanket" || this.ItemDetails[i].item_name === "Comforter"){
              this.bedding.push(this.ItemDetails[i])
              this.bedding_price += parseFloat(this.ItemDetails[i].item_price);
            }else {
              this.drycleaning.push(this.ItemDetails[i])
              this.drycleaning_price += parseFloat(this.ItemDetails[i].item_price);
            }
          }
        }
      }
      this.amount = this.amount - this.bedding_price - this.drycleaning_price;
    }
      })
 
  },error => {
      let alert = this.alert.create({
          title: 'Warning',
          subTitle: 'There is an error! Please Try Again !',
          buttons: ['OK']
      });
      alert.present();
  });

  }

  presentLoading() {
    this.loader = this.loadingCtrl.create({
      content: "Loading..!"
    });
    this.loader.present();
  }

  bed(){
    let bed: any;
    bed = this.bedding;
    let loadDry;
    console.log(bed)

    if(this.bedding != null && this.bedding.length != 0){
      for(let i=0; i<this.bedding.length; i++){
        let s = bed[i].item_name;
        let k = parseInt((<HTMLInputElement>document.getElementById(s+"king")).value);
        let q = parseInt((<HTMLInputElement>document.getElementById(s+"queen")).value);
        let f = parseInt((<HTMLInputElement>document.getElementById(s+"full")).value);
        if(isNaN(k)){
          k = parseInt("0")
        }
        if(isNaN(q)){
          q = parseInt("0")
        }
        if(isNaN(f)){
          f = parseInt("0")
        }
        if((k+q+f) != bed[i].item_qty ){
          let alert = this.alert.create({
            title: 'Warning',
            subTitle: bed[i].item_name +' quantity is incorrect',
            buttons: ['OK']
        });
        alert.present();
        loadDry = 0;
        } else {
          console.log(this.variableItemsPriceData)
          let vData = this.variableItemsPriceData.variableItemsPriceData;
          let king_price = 0.0;
          let queen_price = 0.0;
          let full_price = 0.0;
          let order_variableItem_details: any;
          for(let j=0;j<vData.length;j++){
            this.storage.get("order_variableItem_details").then((data) => {
              data = [];
            })
            if(vData[j].name == s && vData[j].size == "king" && k > 0){
              king_price = parseFloat(vData[j].price)*k;
              this.amount += king_price;
              order_variableItem_details = {
                "id" : this.empOrderData.order_token,
                "name" : s,
                "size" : "King",
                "price" : parseFloat(vData[j].price),
                "qty" : k
              }
              this.bed_items.push(order_variableItem_details);
            }
            if(vData[j].name == s && vData[j].size == "queen" && q > 0){
              queen_price = parseFloat(vData[j].price)*q;
              this.amount += queen_price;
              order_variableItem_details = {
                "id" : this.empOrderData.order_token,
                "name" : s,
                "size" : "Queen",
                "price" : parseFloat(vData[j].price),
                "qty" : q
              }
              this.bed_items.push(order_variableItem_details);
            }
            if(vData[j].name == s && vData[j].size == "full" && f > 0){
              full_price = parseFloat(vData[j].price)*f;
              this.amount += full_price;
              order_variableItem_details = {
                "id" : this.empOrderData.order_token,
                "name" : s,
                "size" : "Full",
                "price" : parseFloat(vData[j].price),
                "qty" : f
              }
              this.bed_items.push(order_variableItem_details);
            }
          }
          loadDry = 1;
        }
      }
      if(loadDry == 1){
        this.dry();
      }
    }
  }

  dry(){
    let dry: any;
    let order_variableItem_details: any;
    dry = this.drycleaning;
    console.log(dry)
    let loadVerify;
    if(this.drycleaning != null && this.drycleaning.length != 0){
      for(let i=0; i<this.drycleaning.length; i++){
        let s = dry[i].item_name;
        let small = parseInt((<HTMLInputElement>document.getElementById(s+"small")).value);
        let medium = parseInt((<HTMLInputElement>document.getElementById(s+"medium")).value);
        let large = parseInt((<HTMLInputElement>document.getElementById(s+"large")).value);
        if(isNaN(small)){
          small = parseInt("0")
        }
        if(isNaN(medium)){
          medium = parseInt("0")
        }
        if(isNaN(large)){
          large = parseInt("0")
        }
        if((small+medium+large) != dry[i].item_qty ){
          let alert = this.alert.create({
            title: 'Warning',
            subTitle: dry[i].item_name +' quantity is wrong',
            buttons: ['OK']
        });
        alert.present();
        this.amount = this.empOrderData.amount;
        this.getVariableItems();
        loadVerify = 0;
        }else {
          let vData = this.variableItemsPriceData.variableItemsPriceData;
          let small_price = 0.0;
          let medium_price = 0.0;
          let large_price = 0.0;
          for(let j=0;j<vData.length;j++){
            if(vData[j].name == s && vData[j].size == "small" && small > 0){
              small_price = parseFloat(vData[j].price)*small;
              this.amount += small_price;
              order_variableItem_details = {
                "id" : this.empOrderData.order_token,
                "name" : s,
                "size" : "Small",
                "price" : parseFloat(vData[j].price),
                "qty" : small
              }
              this.bed_items.push(order_variableItem_details);
            }
            if(vData[j].name == s && vData[j].size == "medium" && medium > 0){
              medium_price = parseFloat(vData[j].price)*medium;
              this.amount += medium_price;
              order_variableItem_details = {
                "id" : this.empOrderData.order_token,
                "name" : s,
                "size" : "Medium",
                "price" : parseFloat(vData[j].price),
                "qty" : medium
              }
              this.bed_items.push(order_variableItem_details);
            }
            if(vData[j].name == s && vData[j].size == "large" && large > 0){
              large_price = parseFloat(vData[j].price)*large;
              this.amount += large_price;
              order_variableItem_details = {
                "id" : this.empOrderData.order_token,
                "name" : s,
                "size" : "Large",
                "price" : parseFloat(vData[j].price),
                "qty" : large
              }
              this.bed_items.push(order_variableItem_details);
            }
          }
          loadVerify = 1;
        }
      }
      if(loadVerify == 1){
        this.verify();
      }
    }
  }


  verify(){

    console.log(this.bed_items)
    
    let bed_dry: any;
    bed_dry = this.bed_items;
    this.storage.get("order_variableItem").then((data) => {
      data = [];
      for(let i = 0; i < bed_dry.length; i++){
      data.push({
        "id" : bed_dry[i].id,
        "name" : bed_dry[i].name,
        "size" : bed_dry[i].size,
        "price" : parseFloat(bed_dry[i].price),
        "qty" : parseInt(bed_dry[i].qty)
        });
        this.storage.set("order_variableItem",data);
      }
    });
    let variableItemsSave: any;
    this.storage.get("order_variableItem").then((data) => {
      variableItemsSave = data;
      console.log(variableItemsSave);
    })

    // this.storage.get("order_variableItem_details").then((data) => {
    //                          console.log(data);
    //                        })
    // this.storage.remove("order_variableItem_details");
    
    let alert = this.alert.create({
      title: 'Do you want to proceed',
      subTitle: 'Grand total: $'+parseFloat(this.amount).toFixed(2),
      buttons: [
      {
        text: 'Yes',
        handler: () => {
          this.presentLoading();
          this.data.amount = parseFloat(this.amount).toFixed(2);
          this.data.customer_id = this.empOrderData.customer_id;
          let data = JSON.stringify(this.data);
          let headers = new Headers();
          headers.append('Content-Type', 'application/json');
          this.http.post('http://www.broadway-bubbles.com/stripe/payment_on_default_card.php', data, headers).subscribe((res) => {
            const response = res.json()
            this.loader.dismiss();
            if(response.status) {
              this.order.amount = this.data.amount;
              this.order.weight = parseFloat(this.data.weight);
              const userData = JSON.parse(localStorage.getItem('data'));
              this.order.user_id = parseInt(userData.userData.user_id);
              this.order.token = userData.userData.token;
              this.order.order_id = this.empOrderData.order_id;
              this.authService.postData(this.order,"updateOrder").then((result) => {
                let salert = this.alert.create({
                  title: 'Success',
                  subTitle: 'Amount Charged Successfully',
                  buttons: [
                  {
                    text: 'Ok',
                    handler: () => {
                      this.authService.postData(variableItemsSave,"variableItemsSave").then((result) => {
                        console.log(result);
                      })
                      this.navCtrl.pop()
                    }
                  }
                ]
              });
              salert.present();      
              })
            }
          })
        
        }
      },
      {
        text: 'Cancel',
        handler: () => {
          this.data.weight = "";
          this.amount = this.empOrderData.amount;
          this.getVariableItems();
        }
      }
    ]
  });
  alert.present(); 
  }


  charge(){
    this.getTotal();
    this.bed();
  }
}



// import { Network } from 'ionic-native';

// declare var navigator: any;
// declare var Connection: any; 

// this.platform.ready().then(() => {
//     let disconnectSub = Network.onDisconnect().subscribe(() => {
//       console.log('you are offline');
//     });

//     let connectSub = Network.onConnect().subscribe(()=> {
//       console.log('you are online');
//     });
//   });
// }

// http://www.fizerkhan.com/blog/posts/Showing-No-internet-connection-message-in-Ionic-application.html
//https://www.youtube.com/watch?v=VhyKYphZLwk