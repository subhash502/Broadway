import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { EmpOrderDetailsPage } from './emp-order-details';

@NgModule({
  declarations: [
    EmpOrderDetailsPage,
  ],
  imports: [
    IonicPageModule.forChild(EmpOrderDetailsPage),
  ],
})
export class EmpOrderDetailsPageModule {}
