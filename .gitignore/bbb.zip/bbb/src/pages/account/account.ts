import { PaymentDetailsPage } from './../payment-details/payment-details';
import { Component } from '@angular/core';
import { NavController, NavParams } from 'ionic-angular';
import { AddressPage } from './../address/address';

@Component({
  selector: 'page-account',
  templateUrl: 'account.html',
})
export class AccountPage {

  public userDetails: any;

  constructor(public navCtrl: NavController, public navParams: NavParams) {
    const data = JSON.parse(localStorage.getItem('data'));
    this.userDetails = data.userData; 
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad AccountPage');
  }

  address() {
    this.navCtrl.push(AddressPage);
  }

  payment(){
    this.navCtrl.push(PaymentDetailsPage);
  }

}
