import { ShowMapPage } from './../show-map/show-map';
import { LoginPage } from './../login/login';
import { Component } from '@angular/core';
import { NavController, NavParams, AlertController} from 'ionic-angular';
import { AuthServiceProvider } from './../../providers/auth-service/auth-service';
import {App} from 'ionic-angular';

@Component({
  selector: 'page-express-d',
  templateUrl: 'express-d.html',
})
export class ExpressDPage {
  public userDetails: any;
  public responseData: any;
  public dataset: any;
  public length: number;
  userPostData = {"user_id":"", "token":"", "order_id": Number, "order_status": ""};

  constructor(public app: App, public navCtrl: NavController, public navParams: NavParams, public alert: AlertController, public authService: AuthServiceProvider) {
    const data = JSON.parse(localStorage.getItem('data'));
    this.userDetails = data.userData;
    this.userPostData.user_id = this.userDetails.user_id;
    this.userPostData.token = this.userDetails.token;
    this.getAddress(); 
  }

  changeTime(data){
    let h = data.slice(0,2);
    h++;
    h++;
    h++;
    h++;
    let m = data.slice(2,5);
    let s = ""
    if(h < 12){
      s = " AM";
    }else {
      h = h-12;
      s = " PM"
    }
    return h+m+s;
  }

  changeAddress(addr){
    let s = addr.replace(' New York, NY', '');
    s = s.replace(', USA','');
    return s;
  }

  getAddress(){
    this.authService.postData(this.userPostData,"expressDelivery").then((result) => {
      this.responseData = result;
      if(this.responseData.addressData){
        this.dataset = this.responseData.addressData;
        this.length = this.responseData.addressData.length;
      }else {
        console.log("No Access,,!");
      }
      
  },error => {
      let alert = this.alert.create({
          title: 'Warning',
          subTitle: 'There is an error! Please Try Again !',
          buttons: ['OK']
      });
      alert.present();
  });
  }

  delivery(id, msgIndex){
    if(id > 0)
    this.userPostData.order_id = id;
    this.userPostData.order_status = "Delivered";
    console.log(this.userPostData);
    this.authService.postData(this.userPostData,"driverInput").then((result) => {
      this.responseData = result;
      console.log(this.responseData);
      if(this.responseData.success){
       let alert = this.alert.create({
                title: 'Success',
                subTitle: 'Order status updated !',
                buttons: ['OK']
            });
            alert.present();
            this.dataset.splice(msgIndex, 1);
            this.getAddress();
      }else {
        console.log("No Access,,!");
      }
      
  },error => {
      let alert = this.alert.create({
          title: 'Warning',
          subTitle: 'There is an error! Please Try Again !',
          buttons: ['OK']
      });
      alert.present();
  });
  }

  map(){
    this.navCtrl.push(ShowMapPage)
  }

  logout(){
    localStorage.clear();
    this.app.getRootNav().setRoot(LoginPage);
  }

}
