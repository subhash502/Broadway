import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { ExpressDPage } from './express-d';

@NgModule({
  declarations: [
    ExpressDPage,
  ],
  imports: [
    IonicPageModule.forChild(ExpressDPage),
  ],
})
export class ExpressDPageModule {}
