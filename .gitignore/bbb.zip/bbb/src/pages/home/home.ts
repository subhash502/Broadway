import { GetPaymentPage } from './../get-payment/get-payment';
import { GetAddressPage } from './../get-address/get-address';
import { PaymentPage } from './../payment/payment';
import { Storage } from '@ionic/storage';
import { CartPage } from './../cart/cart';
import { Component } from '@angular/core';
import { NavController, AlertController, ModalController, ToastController } from 'ionic-angular';
import { PageGmapAutocompletePage } from './../page-gmap-autocomplete/page-gmap-autocomplete';
import { DryCleaningPage } from './../dry-cleaning/dry-cleaning';
import { WashingPage } from './../washing/washing';
import { AuthServiceProvider } from './../../providers/auth-service/auth-service';

@Component({
  selector: 'page-home',
  templateUrl: 'home.html'
})
export class HomePage {

  public washtime :any ;
  public isToggled: boolean;
  item: string;
  hour: number;
  addr_pay : {"address":"","pay":""}
  payment_method : any;
  today
  constructor(public modalCtrl: ModalController, public toastCtrl: ToastController, public navCtrl: NavController, public storage: Storage, public authService: AuthServiceProvider, public alert: AlertController) {
    
    this.payment_method = {}

    this.storage.get("payment_method").then((data)=>{
      data = [];
      data.push({
        "name": "Stripe"
      })
      
      this.storage.set("payment_method",data);
    });

    this.isToggled = false;
    var date = new Date();
    
    date.setHours(date.getHours() - 4);
    
    var mins = date.getMinutes();
    var quarterHours = Math.round(mins/15);
    if (quarterHours == 4)
    {
        date.setHours(date.getHours()+1);
    }
    var rounded = (quarterHours*15)%60;
    console.log(date.setMinutes(rounded));
    this.today = date.toISOString();
    this.storage.set("time",this.today);
  }

  dateChanged(){
  
  }

  openModal() {
    this.storage.set("time",this.today);
    if(this.checkTime(this.today.slice(11,16)) == false){
      let alert = this.alert.create({
        title: 'Pickup time',
        subTitle: 'Select pickup time between 7:00 AM to 10:00 PM',
        buttons: ['OK']
    });
    alert.present();
    }else {
    let alert = this.alert.create({
      title: 'Pickup time',
      subTitle: 'Pickup time scheduled at '+ this.changeTime(this.today.slice(11,16)),
      buttons: ['Add Pickup Time',
      {
        text:'Proceed',
        handler: () => {
          this.storage.get("pay").then((data)=>{
            if(data == null){
              let alert = this.alert.create({
                title: 'Add payment method',
                buttons: ['OK']
            });
            alert.present();
            }else {
              this.storage.set("time",this.today);
              let myModal = this.modalCtrl.create(GetAddressPage);
              myModal.onDidDismiss(data => {
                this.item = data;
                this.storage.get("addr").then((data)=>{
                      data = [];
                      data.push(this.item)
                      this.storage.set("addr",data); 
                })	
              });
              myModal.present();
              this.navCtrl.push(CartPage)
            }
          })
        }
      }
    ]
  });
  alert.present();
    }
  }

  changeTime(data){
    let h;
    let m;
    if(data != null){
       h = data.slice(0,2);
       m = data.slice(2,5);
    }
      let s = ""
      if(h < 12){
        s = " AM";
      }else {
        h = h-12;
        s = " PM"
      }
      return h+m+s;
  }

  checkTime(data){
    let h;
    
    if(data != null){
        h = data.slice(0,2);
    }
      
    if(h >=7 && h <= 22){
      return true
    }else {
      return false
    }
  }

  getPayment(){
    let myModal1 = this.modalCtrl.create(GetPaymentPage);
    myModal1.onDidDismiss(data => {
      this.item = data;
      this.storage.get("pay").then((data)=>{
        data = [];
        data.push(this.item)
        this.storage.set("pay",data);
      })    
      
    });
    myModal1.present();
  }

  onGoToLocation() {
    this.navCtrl.push(PageGmapAutocompletePage);
  }

  washing() {
    this.navCtrl.push(WashingPage);
  }

  dry_cleaning() {
    this.navCtrl.push(DryCleaningPage);
  }

  payment() {
    this.navCtrl.push(PaymentPage);
  }

  cart() {

    this.storage.set("time",this.today);

    this.navCtrl.push(CartPage);
  }

  paymentMethod(name){ 
    console.log(name, this.isToggled);
    if(this.isToggled == true){
      this.storage.get("payment_method").then((data)=>{
        data = [];
        data.push({
          "name": name
        })
        this.storage.set("payment_method",data);
        this.storage.get("payment_method").then((data)=>{
          console.log(data);
        });
      })
    }else if (this.isToggled == false) {
      this.storage.get("payment_method").then((data)=>{
        data = [];
        data.push({
          "name": "Stripe"
        })
        this.storage.set("payment_method",data);
        this.storage.get("payment_method").then((data)=>{
          console.log(data);
        });
      })
    }
    
  }

}
