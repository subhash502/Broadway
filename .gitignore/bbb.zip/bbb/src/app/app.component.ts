import { OrdersPage } from './../pages/orders/orders';
import { Component, ViewChild } from '@angular/core';
import { Nav, Platform, LoadingController, AlertController } from 'ionic-angular';
import { StatusBar } from '@ionic-native/status-bar';
import { SplashScreen } from '@ionic-native/splash-screen';
import { Push, PushObject, PushOptions } from '@ionic-native/push';
import { Http, Response, Headers, RequestOptions } from '@angular/http';

import { Storage } from '@ionic/storage';

import { IntroPage } from './../pages/intro/intro';
import { LoginPage } from './../pages/login/login';


@Component({
  templateUrl: 'app.html'
})
export class MyApp {
  @ViewChild(Nav) nav: Nav;

  splash = true;

  rootPage: any = IntroPage;
  loader: any;

  constructor(private push: Push, public http:Http, public platform: Platform, private alertCtrl:AlertController ,public statusBar: StatusBar, public splashScreen: SplashScreen, public loadingCtrl: LoadingController, public storage: Storage) {
    // this.initializeApp();
    this.initPushNotification();
    // this.presentLoading();
   
       this.platform.ready().then(() => {
    
         this.storage.get('introShown').then((result) => {
    
           if(result){
            
            setTimeout(() => {
              this.splash = false;
            }, 3000);
             this.rootPage = LoginPage;
           } else {
            
            setTimeout(() => {
              this.splash = false;
            }, 3000);
             this.zipcode();
             this.rootPage = IntroPage;
             this.storage.set('introShown', true);
           }
    
           //this.loader.dismiss();
    
         });
    
       });    

   }

  zipcode() {
    let alert = this.alertCtrl.create({
      title: 'Your Zip Code',
      inputs: [
          {
              name: 'zipcode',
              placeholder: 'Enter ZipCode',
          }
        ],
        buttons: [
          {
              text: 'Go',
              handler: data => {
                let card = {
                  number: data.zipcode
                };
                if(!isNaN(data.zipcode) && data.zipcode.length == 5){
                  
                if(data.zipcode == 10023 || data.zipcode == 10024 || data.zipcode == 10025){
                  let alert = this.alertCtrl.create({
                    title: 'Splish splash..! We provide service in your area!',
                    
                      buttons: [
                        {
                            text: 'Continue',
                            role: 'cancel',
                        }
                      ]
                    });
                    alert.present();
                }
                else{
                  let alert = this.alertCtrl.create({
                    title: 'Service is not currently available in your area. Please sign up! We will notify you soon.',
                    
                      buttons: [
                        {
                            text: 'Continue',
                            role: 'cancel',
                        }
                      ]
                    });
                    alert.present();
                }

              } else {
                let alert = this.alertCtrl.create({
                  title: 'Invalid Zipcode',
                  
                    buttons: [
                      {
                        text: 'OK',
                        handler: data => {
                          this.zipcode();
                        }
                      }
                    ]
                  });
                  alert.present();
              }
              }
            }
        ]
    });
    alert.present();
  }

  presentLoading() {
    
       this.loader = this.loadingCtrl.create({
         content: "Loading..!"
       });
    
       this.loader.present();
    
     }

  initializeApp() {
    this.platform.ready().then(() => {
      // Okay, so the platform is ready and our plugins are available.
      // Here you can do any higher level native things you might need.
      this.statusBar.styleDefault();
      this.splashScreen.hide();
    });
  }

  saveDeviceToken(t)
  {  
    this.http.get('http://192.168.0.100/ionic/saveToken.php?token='+t)
        .map(res => res.json())
            .subscribe(
              data => {
                alert(JSON.stringify(data));
                },
              err => {
                  console.log("Oops!");
              }
            );
  }

  initPushNotification()
  {
  // to check if we have permission
  this.push.hasPermission()
  .then((res: any) => {
  if (res.isEnabled) {
    // let alert = this.alertCtrl.create({
    //   title: 'push Notification Enabled',
      
    //     buttons: [
    //       {
    //           text: 'Continue',
    //           role: 'cancel',
    //       }
    //     ]
    //   });
    //   alert.present();
  } else {
    let alert = this.alertCtrl.create({
      title: 'Push notification not enabled',
      
        buttons: [
          {
              text: 'Continue',
              role: 'cancel',
          }
        ]
      });
      alert.present();
  }
  });
  
  // to initialize push notifications
  const options: PushOptions = {
    android: {
      senderID: "447594338630"
    },
    ios: {
    alert: 'true',
    badge: true,
    sound: 'false'
    },
    windows: {}
  };
  const pushObject: PushObject = this.push.init(options);
  pushObject.on('notification').subscribe((notification: any) =>{
    console.log('Received a notification', notification);
  
    //Notification Display Section
     let confirmAlert = this.alertCtrl.create({
            title: 'New Notification',
            message: JSON.stringify(notification),
            buttons: [{
              text: 'Ignore',
              role: 'cancel'
            }, {
              text: 'View',
              handler: () => {
                this.nav.push(OrdersPage);
              }
            }]
          });
          confirmAlert.present();
    //
  });
  
  pushObject.on('registration').subscribe((registration: any) => {
    // console.log('Device registered', registration);
    // alert(JSON.stringify(registration));
    this.saveDeviceToken( registration.registrationId);
  });
  
  pushObject.on('error').subscribe(error => console.error('Error with Push plugin', error));
    }

 
}
