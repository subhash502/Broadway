import { OrdersDetailPage } from './../pages/orders-detail/orders-detail';
import { OrdersPage } from './../pages/orders/orders';
import { ShowMapPage } from './../pages/show-map/show-map';
import { ShippingPage } from './../pages/shipping/shipping';
import { NormalPage } from './../pages/normal/normal';
import { ExpressPage } from './../pages/express/express';
import { PaymentDetailsPage } from './../pages/payment-details/payment-details';
import { Geolocation } from '@ionic-native/geolocation';
import { BrowserModule } from '@angular/platform-browser';
import { ErrorHandler, NgModule } from '@angular/core';
import { IonicApp, IonicErrorHandler, IonicModule } from 'ionic-angular';
import { HttpModule } from '@angular/http';
import { IonicStorageModule } from '@ionic/storage';
import { CreditCardDirectivesModule } from 'angular-cc-library';
import { BsModalModule } from 'ng2-bs3-modal';

import { MyApp } from './app.component';
import { HomePage } from '../pages/home/home';
import { IntroPage } from './../pages/intro/intro';
import { LoginPage } from './../pages/login/login';
import { SignupPage } from './../pages/signup/signup';
import { MenuPage } from './../pages/menu/menu';
import { CartPage } from './../pages/cart/cart';
import { HelpPage } from './../pages/help/help';
import { PricingPage } from './../pages/pricing/pricing';
import { AccountPage } from './../pages/account/account';
import { ModalAutocompleteItemsPage } from './../pages/modal-autocomplete-items/modal-autocomplete-items';
import { PageGmapAutocompletePage } from './../pages/page-gmap-autocomplete/page-gmap-autocomplete';
import { DryCleaningPage } from './../pages/dry-cleaning/dry-cleaning';
import { WashingPage } from './../pages/washing/washing';
import { PaymentPage } from './../pages/payment/payment';
import { EmployeePage } from './../pages/employee/employee';
import { DriverPage } from './../pages/driver/driver';
import { AddressPage } from './../pages/address/address';
import { GetAddressPage } from './../pages/get-address/get-address';
import { GetPaymentPage } from './../pages/get-payment/get-payment';
import { CartItemPage } from './../pages/cart-item/cart-item';
import { EmpOrderDetailsPage } from './../pages/emp-order-details/emp-order-details';
import { NormalDPage } from './../pages/normal-d/normal-d';
import { ExpressDPage } from './../pages/express-d/express-d';
import { Push, PushObject, PushOptions } from '@ionic-native/push';

import { StatusBar } from '@ionic-native/status-bar';
import { SplashScreen } from '@ionic-native/splash-screen';
import { AuthServiceProvider } from '../providers/auth-service/auth-service';
import { TextMaskModule } from 'angular2-text-mask';

@NgModule({
  declarations: [
    MyApp,
    HomePage,
    IntroPage,
    LoginPage,
    SignupPage,
    MenuPage,
    CartPage,
    HelpPage,
    PricingPage,
    AccountPage,
    ModalAutocompleteItemsPage,
    PageGmapAutocompletePage,
    WashingPage,
    DryCleaningPage,
    PaymentPage,
    EmployeePage,
    DriverPage,
    AddressPage,
    PaymentDetailsPage,
    GetAddressPage,
    GetPaymentPage,
    CartItemPage,
    ShippingPage,
    NormalPage,
    ExpressPage,
    ShowMapPage,
    OrdersPage,
    OrdersDetailPage,
    EmpOrderDetailsPage,
    NormalDPage,
    ExpressDPage
  ],
  imports: [
    BrowserModule,
    CreditCardDirectivesModule,
    HttpModule,
    TextMaskModule,
    BsModalModule,
    IonicModule.forRoot(MyApp),
    IonicStorageModule.forRoot()
  ],
  bootstrap: [IonicApp],
  entryComponents: [
    MyApp,
    HomePage,
    IntroPage,
    LoginPage,
    SignupPage,
    MenuPage,
    CartPage,
    HelpPage,
    PricingPage,
    AccountPage,
    ModalAutocompleteItemsPage,
    PageGmapAutocompletePage,
    WashingPage,
    DryCleaningPage,
    PaymentPage,
    EmployeePage,
    DriverPage,
    AddressPage,
    PaymentDetailsPage,
    GetAddressPage,
    GetPaymentPage,
    CartItemPage,
    ShippingPage,
    NormalPage,
    ExpressPage,
    ShowMapPage,
    OrdersPage,
    OrdersDetailPage,
    EmpOrderDetailsPage,
    NormalDPage,
    ExpressDPage
  ],
  providers: [
    Push,
    StatusBar,
    SplashScreen,
    IonicStorageModule,
    Geolocation,
    {provide: ErrorHandler, useClass: IonicErrorHandler},
    AuthServiceProvider
  ]
})
export class AppModule {}
